# Audio Transcription with Speaker Diarization — Quick Start

This project provides a simple web app that takes a meeting or interview recording, converts it to text and automatically labels each speaker with timestamps.  Follow these concise steps to get it running in VS Code on your own machine.

## 1. Set up your tools

1. **Google Cloud credentials** — Create a service account in the Google Cloud Console with access to the Speech‑to‑Text API, download the JSON key file, and place it in your project folder (for example, `credentials.json`).

## 2. Open the project in VS Code

1. Launch VS Code and choose **File → Open Folder…**. Select the folder that contains this project.

2. Open a new terminal inside VS Code via **Terminal → New Terminal**.  The terminal starts in your project folder.

## 3. Create and activate a virtual environment

In the VS Code terminal, run the following commands:

```powershell
# create a virtual environment called .venv
python -m venv .venv

# activate it (Windows PowerShell)
.\.venv\Scripts\Activate.ps1

# (on macOS/Linux you’d use: source .venv/bin/activate)

# you should now see (.venv) or similar in your terminal prompt
```

## 4. Install dependencies

Still in the activated virtual environment, install the required Python packages:

```powershell
pip install Flask google-cloud-speech pydub
```

These three libraries provide the web server, the Google Speech‑to‑Text client, and audio file handling.  If you see a “module not found” error later, rerun this command.

## 5. Configure your API key

You need to tell the Google client library where to find your service‑account JSON key.  In the same terminal run:


```bash
export GOOGLE_APPLICATION_CREDENTIALS="credentials.json"
```

## 6. Run the app

Now start the Flask server by running:

```powershell
python app.py
```

If everything is configured correctly, you’ll see output ending with:

```
 * Running on http://127.0.0.1:5001 (Press CTRL+C to quit)
```

Leave this terminal running; it is serving your web app.

## 7. Use the web interface

1. Open your browser and go to `http://127.0.0.1:5001`.  You should see the **Diarize.ai** upload page.
2. Click **Choose file** and select an audio file in `.wav`, `.mp3`, `.flac`, or `.m4a` format.
3. Click **Transcribe & diarize**.  The page will show a “Processing…” message.  

4. The **Speaker‑wise transcript** section lists each speaker’s lines along with start and end times.  A **Download transcript** button lets you save the transcript as a text file.

## 8. Tips and troubleshooting

- If you get a credentials error, verify that `GOOGLE_APPLICATION_CREDENTIALS` points to the correct JSON key file and that the file is valid (do not open or edit it manually).
